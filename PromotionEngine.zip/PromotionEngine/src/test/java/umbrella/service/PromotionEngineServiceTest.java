/*
package umbrella.service;

import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import umbrella.dtos.CartDto;
import umbrella.dtos.ItemDto;
import umbrella.model.Rules;
import umbrella.repository.CartRepository;
import umbrella.repository.RulesRepository;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;


@RunWith(MockitoJUnitRunner.class)
public class PromotionEngineServiceTest {

    @Mock
    private RulesRepository rulesRepository;

    @Mock
    private CartRepository cartRepository;

    @InjectMocks
    private PromotionEngineService promotionEngineService;

    @Before
    public void setUp() {
        // mock the rules repository
        Rules rule1 = new Rules();
        rule1.setPromotionName("Scenario1");
        rule1.setActualValue(150.0);
        rule1.setPromotionValue(130.0);
        Map<String, Integer> eligibilityCriteria1 = new HashMap<>();
        eligibilityCriteria1.put("A", 3);
        rule1.setEligibilityCriteria(eligibilityCriteria1);

        List<Rules> rulesList = new ArrayList<>();
        rulesList.add(rule1);
        Mockito.when(rulesRepository.findAll()).thenReturn(rulesList);
    }

    @Test
    public void testCheckEligibility() {
        List<ItemDto> itemDtoList = new ArrayList<>();
        ItemDto item1 = new ItemDto();
        item1.setSkuId("A");
        item1.setCount(1L);
        item1.setUnitPrice(50.0);
        itemDtoList.add(item1);

        ItemDto item2 = new ItemDto();
        item2.setSkuId("B");
        item2.setCount(1L);
        item2.setUnitPrice(30.0);
        itemDtoList.add(item2);

        ItemDto item3 = new ItemDto();
        item3.setSkuId("C");
        item3.setCount(1L);
        item3.setUnitPrice(20.0);
        itemDtoList.add(item3);

        CartDto cartDto = new CartDto();
        cartDto.setItemList(itemDtoList);
        cartDto.setActualValue(100.0);


        promotionEngineService.checkEligibility(cartDto);

        assertNotEquals("Scenario1", cartDto.getAppliedPromotionName());
        assertEquals(100.0, cartDto.getActualValue());
    }

    @Test
    public void testApplyPromotion() {

        List<ItemDto> itemDtoList = new ArrayList<>();
        ItemDto item1 = new ItemDto();
        item1.setSkuId("A");
        item1.setCount(3L);
        itemDtoList.add(item1);


        CartDto cartDto = new CartDto();
        cartDto.setItemList(itemDtoList);
        cartDto.setActualValue(150.0);


        Rules rule = new Rules();
        rule.setPromotionName("Scenario2");
        rule.setActualValue(150.0);
        rule.setPromotionValue(130.0);

        Map<String, Integer> eligibilityCriteria = new HashMap<>();
        eligibilityCriteria.put("A", 3);
        rule.setEligibilityCriteria(eligibilityCriteria);


        CartDto result = promotionEngineService.applyPromotion(cartDto, rule);

        assertEquals("Scenario2", result.getAppliedPromotionName());
        assertEquals(130, result.getPromotedValue());
    }
}

*/
