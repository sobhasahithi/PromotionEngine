package umbrella.controller;

import umbrella.dtos.CartDto;
import umbrella.dtos.ItemDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import umbrella.service.CartService;

@RestController
public class CartController {


    @Autowired
    CartService cartService;

    @GetMapping("/mycart/{userName}")
    public CartDto readCart(@PathVariable String userName){
        System.out.print("recieved get reuest"+userName);
    CartDto cartDto = cartService.readCart(userName);
     return cartDto;
 }

    @PutMapping("/mycart/{userName}")
    public CartDto addItemToCart(@PathVariable String userName , @RequestBody ItemDto itemDto){
     return cartService.addItemToCart(userName, itemDto);

 }
    @DeleteMapping("/mycart/{userName}")
    public CartDto deleteItemFromCart(@PathVariable String userName , @RequestBody ItemDto itemDto){
       return cartService.deleteItemFromCart(userName, itemDto);

    }

    @PostMapping("/mycart/{userName}")
    public CartDto createCart(@PathVariable String userName , @RequestBody ItemDto itemDto){
       return cartService.createCart(userName, itemDto);

    }

}
