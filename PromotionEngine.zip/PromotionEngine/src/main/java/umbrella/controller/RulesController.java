package umbrella.controller;

import ch.qos.logback.core.joran.spi.RuleStore;
import org.dom4j.rule.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import umbrella.dtos.CartDto;
import umbrella.dtos.ItemDto;
import umbrella.dtos.RuleDto;
import umbrella.service.CartService;
import umbrella.service.RuleService;

import java.util.List;
import java.util.Optional;

@RestController
public class RulesController {

    @Autowired
    RuleService ruleService;

    @GetMapping("/rules")
    public List<RuleDto> readRulels(){
       return ruleService.readAllRules();
    }
    @GetMapping("/rules/{promotionName}")
    public Optional<RuleDto> readOneRule(@PathVariable String promotionName){
        return ruleService.readOneRule(promotionName);

    }

    @PutMapping("/rules/{promotionName}")
    public Optional<RuleDto> updateRule(@PathVariable String promotionName , @RequestBody RuleDto ruleDto){
        return ruleService.updateRule(promotionName, ruleDto);

    }
    @DeleteMapping("/rules/{promotionName}")
    public void deleteRule(@PathVariable String promotionName ){
      ruleService.deleteRule(promotionName);

    }

    @PostMapping("/rules")
    public RuleDto createCart( @RequestBody RuleDto ruleDto){
        return ruleService.createRule( ruleDto);

    }
}
