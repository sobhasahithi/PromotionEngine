package umbrella.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import umbrella.model.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;


@Repository
public interface CartRepository extends JpaRepository<Cart,Long> {

    Optional<Cart> findByUserName(String userName);
}
