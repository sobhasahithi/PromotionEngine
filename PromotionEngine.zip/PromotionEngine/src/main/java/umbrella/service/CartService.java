package umbrella.service;

import org.springframework.stereotype.Service;
import umbrella.dtos.CartDto;
import umbrella.dtos.ItemDto;
import umbrella.model.Cart;
import umbrella.model.Item;
import org.springframework.beans.factory.annotation.Autowired;
import umbrella.repository.CartRepository;


import java.util.*;

@Service
public class CartService {
    @Autowired
    CartRepository cartRepository;
    @Autowired
    PromotionEngineService promotionEngineService;
    public CartDto readCart(String userName){
      Optional<Cart> userCart= cartRepository.findByUserName(userName);
        CartDto cartDto = new CartDto();
        maptoCartDto(userCart.get(), cartDto);
     return cartDto;
    }

   public CartDto createCart(String username, ItemDto itemDto){
       Optional<Cart> userCart = cartRepository.findByUserName(username);
       CartDto cartDto = new CartDto();
       if(userCart.isPresent()){
        return maptoCartDto(userCart.get(), cartDto);
       }
       else{
           Cart freshCart = new Cart();
           freshCart.setAppliedPromotionName("");
           freshCart.setUserName(username);
           freshCart.setPromotedValue(null);
           freshCart.setActualValue(itemDto.getUnitPrice());
           freshCart.setAppliedPromotionName(null);
           List<Item> itemList = new ArrayList<>();
           freshCart.setItemList(itemList);
           this.mapToItemEntity(itemDto,freshCart);
           cartRepository.save(freshCart);
           return maptoCartDto(freshCart, cartDto);
       }
   }
   public CartDto addItemToCart(String username , ItemDto itemDto){
      Optional<Cart> userCart = cartRepository.findByUserName(username);
       List<Item> itemList;
       CartDto cartDto = new CartDto();
      if(userCart.isPresent()){
          Cart cartEntity=userCart.get();
          this.mapToItemEntity(itemDto,userCart.get());
          cartEntity.setItemList(userCart.get().getItemList());
          this.maptoCartDto(cartEntity, cartDto);
          this.calculateActualCartValue(cartDto);
          promotionEngineService.checkEligibility(cartDto);
          this.adjustPromotion(cartDto,cartEntity);
          cartRepository.save(cartEntity);
        return cartDto;

      }
      return null;
   }
    public CartDto deleteItemFromCart(String username , ItemDto itemDto){
        Optional<Cart> userCart = cartRepository.findByUserName(username);
        CartDto cartDto = new CartDto();
        if(userCart.isPresent()){
            Cart cartEntity=userCart.get();
            List<Item> itemList = cartEntity.getItemList();
            //remove the last added itemDto of this type
            Optional<Item> deletedItem= itemList.stream().filter(item -> item.getSkuId().equals(itemDto.getSkuId())).findFirst();

           if(deletedItem.isPresent()) {
               itemList.stream().filter(item -> item.getId().equals(deletedItem.get().getId())).findFirst().get().setCount(deletedItem.get().getCount()-1);
               //cartEntity.setItemList(itemList);
               this.maptoCartDto(cartEntity, cartDto);
               this.calculateActualCartValue(cartDto);
               promotionEngineService.checkEligibility(cartDto);
               this.adjustPromotion(cartDto,cartEntity);
               cartRepository.save(cartEntity);
           }

            return cartDto;

        }
        return null;
    }
   public void calculateActualCartValue(CartDto cartDto){
      cartDto.setActualValue(0.0);
      cartDto.getItemList()
                  .forEach(itemDto ->
                          cartDto.setActualValue(
                                  cartDto.getActualValue()+
                                  itemDto.getUnitPrice() * itemDto.getCount()
                          )
                  );



    }


    public CartDto maptoCartDto(Cart userCart, CartDto cartDto){
        cartDto.setUserName(userCart.getUserName());
        cartDto.setPromotedValue(userCart.getPromotedValue());
        cartDto.setActualValue(userCart.getActualValue());
        cartDto.setAppliedPromotionName(userCart.getAppliedPromotionName());
        List<ItemDto> itemDtoList = new ArrayList<>();
        userCart.getItemList().forEach(p-> itemDtoList.add(this.mapToItemDto(p)));
        cartDto.setItemList(itemDtoList);
        return cartDto;
    }


    public void mapToItemEntity(ItemDto itemDto,Cart userCart){
        Item item;
        List<Item> itemList = userCart.getItemList();
        if(itemList.isEmpty() || itemList.stream().noneMatch(x->x.getSkuId().equals(itemDto.getSkuId()))) {
            item= new Item();
            item.setSkuId(itemDto.getSkuId());
            item.setUnitPrice(itemDto.getUnitPrice());
            item.setCount(1L);
            itemList.add(item);
        }
        else{
           item=itemList.stream().filter(x->x.getSkuId().equals(itemDto.getSkuId())).findFirst().get();
            item.setCount(item.getCount()+1);
        }

    }
    public ItemDto mapToItemDto(Item item){

        ItemDto itemDto = new ItemDto();
        itemDto.setSkuId(item.getSkuId());
        itemDto.setUnitPrice(item.getUnitPrice());
        itemDto.setCount(item.getCount());
        return itemDto;

    }
    public void adjustPromotion(CartDto cartDto,Cart cartEntity){
        cartEntity.setAppliedPromotionName(cartDto.getAppliedPromotionName());
        cartEntity.setActualValue(cartDto.getActualValue());
        cartEntity.setPromotedValue(cartDto.getPromotedValue());
    }
}
