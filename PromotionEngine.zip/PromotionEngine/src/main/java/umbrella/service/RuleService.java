package umbrella.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import umbrella.dtos.RuleDto;
import umbrella.model.Rules;
import umbrella.repository.RulesRepository;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class RuleService {
@Autowired
    RulesRepository rulesRepository;

    public List<RuleDto> readAllRules(){
        List<Rules> rulesList= rulesRepository.findAll();
        List<RuleDto> ruleDtoList = new ArrayList<>();
       if(null!=rulesList && !rulesList.isEmpty()){
           rulesList.stream().forEach(rule -> {
                                          ruleDtoList.add(this.mapEntityToDto(rule));
                                            });
       }
        return ruleDtoList;
    }

    public Optional<RuleDto> readOneRule(String promotionName){
        List<Rules> rulesList= rulesRepository.findByPromotionName(promotionName);
       if( null!=rulesList && !rulesList.isEmpty()){
          return Optional.of(this.mapEntityToDto(rulesList.stream().findFirst().get()));
       }

        return Optional.empty();
    }



    public Optional<RuleDto> updateRule(String promotionName ,RuleDto ruleDto){
      List<Rules> rulesList= rulesRepository.findByPromotionName(promotionName);
       if(null!=rulesList && !rulesList.isEmpty()){
           Rules rule= this.mapDtoToEntity(ruleDto) ;
           rule.setId(rulesList.stream().findFirst().get().getId());
           rulesRepository.save(rule);
        }

        return Optional.of(ruleDto);

    }

    @Transactional
    public void deleteRule( String promotionName ){
        rulesRepository.deleteByPromotionName(promotionName);
    }


    public RuleDto createRule( RuleDto ruleDto){


        return  this.mapEntityToDto( rulesRepository.save(this.mapDtoToEntity(ruleDto)));

    }
    public Rules mapDtoToEntity(RuleDto ruleDto){

        Rules ruleEntity = new Rules();
        ruleEntity.setId(ruleDto.getId());
        ruleEntity.setActualValue(ruleDto.getActualValue());
        ruleEntity.setEligibilityCriteria(ruleDto.getEligibilityCriteria());
        ruleEntity.setPromotionName(ruleDto.getPromotionName());
        ruleEntity.setPromotionValue(ruleDto.getPromotionValue());
          return ruleEntity;

    }
    public RuleDto mapEntityToDto(Rules ruleEntity){
      RuleDto ruleDto=new RuleDto();
       ruleDto.setId(ruleEntity.getId());
       ruleDto.setActualValue(ruleEntity.getActualValue());
       ruleDto.setEligibilityCriteria(ruleEntity.getEligibilityCriteria());
       ruleDto.setPromotionName(ruleEntity.getPromotionName());
       ruleDto.setPromotionValue(ruleEntity.getPromotionValue());
       return ruleDto;
    }
}
