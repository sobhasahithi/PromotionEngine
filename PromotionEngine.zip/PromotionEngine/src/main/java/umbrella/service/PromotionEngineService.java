package umbrella.service;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.catalina.mapper.Mapper;
import umbrella.dtos.CartDto;
import umbrella.dtos.ItemDto;
import umbrella.model.Item;
import umbrella.model.Rules;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import umbrella.repository.CartRepository;
import umbrella.repository.RulesRepository;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PromotionEngineService {
    @Autowired
    RulesRepository rulesRepository;
    @Autowired
    CartRepository cartRepository;

    public void checkEligibility(CartDto cartDto){
        ObjectMapper mapper = new ObjectMapper();

        List<Rules> rulesList = rulesRepository.findAll();
        rulesList.forEach(x->System.out.println("*********"+x.getPromotionName()));
        Optional<Rules> matchRule = Optional.empty();

        matchRule= rulesList.stream().filter(rule-> applyRuleToCart(rule,cartDto.getItemList())).findFirst();


                if( matchRule.isPresent()){
                    System.out.println("Matched rule"+matchRule.get().getPromotionName());
                    if (null==cartDto.getAppliedPromotionName())
                        applyPromotion(cartDto,matchRule.get());
                    else if (!cartDto.getAppliedPromotionName().equals(matchRule.get().getPromotionName()))
                        System.out.println("Mutual Exclusion in Action....Can't apply another Promotion");

                }
                else{
                    cartDto.setAppliedPromotionName(null);
                    cartDto.setPromotedValue(null);
                }

 }

    public CartDto applyPromotion(CartDto cartDto, Rules rule){
           List<ItemDto> itemList= cartDto.getItemList();
          cartDto.setPromotedValue(0.0);
            itemList.stream().forEach(itemDto ->
                       cartDto.setPromotedValue(
                               cartDto.getActualValue()- rule.getActualValue()+rule.getPromotionValue()
                        )
               );
        cartDto.setAppliedPromotionName(rule.getPromotionName());

        return cartDto;
    }


    public boolean applyRuleToCart(Rules rule,List<ItemDto> itemDtoList){


      return rule.getEligibilityCriteria().keySet().stream().allMatch(key->

              itemDtoList.stream().anyMatch(
                      itemDto ->
                              itemDto.getSkuId().equals(key)
                                      &&
                                      itemDto.getCount().longValue()>=(Long.parseLong(rule.getEligibilityCriteria().get(key).toString()))
              )
      );
    }
}
