package umbrella.model;

import javax.persistence.*;

import  org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name="Item")
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id ;

    @Column(name="sku_id")
    String skuId;

    @Column(name="unit_price")
    Double unitPrice;

    @Column(name="count")
    Long count;

    public Item(String skuId, Double unitPrice,Cart cart) {
        this.skuId = skuId;
        this.unitPrice = unitPrice;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }
    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public Item() {

    }
    public Long getId() {
        return id;
    }

    public Double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
