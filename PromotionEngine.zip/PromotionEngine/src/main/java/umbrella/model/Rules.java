package umbrella.model;



import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import com.vladmihalcea.hibernate.type.json.JsonType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import umbrella.mapper.HashMapConverter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

@Entity
@Table(name="Rules")
public class Rules implements Comparable<Rules> {


    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="id")
    @Id
    Long id;

    Double actualValue;
    Double promotionValue;



    //comma separated


    @Column(name="eligibility_criteria" ,columnDefinition = "varchar2")
    @Convert(converter = HashMapConverter.class)
    private Map<String, String> eligibilityCriteria = new HashMap<>();
   // String eligibilityCriteria;
    String promotionName;





    public Double getActualValue() {
        return actualValue;
    }

    public void setActualValue(Double actualValue) {
        this.actualValue = actualValue;
    }



    public Double getPromotionValue() {
        return promotionValue;
    }

    public void setPromotionValue(Double promotionValue) {
        this.promotionValue = promotionValue;
    }

    public String getPromotionName() {
        return promotionName;
    }

    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }


    public Map getEligibilityCriteria() {
        return eligibilityCriteria;
    }

    public void setEligibilityCriteria(Map eligibilityCriteria) {
        this.eligibilityCriteria = eligibilityCriteria;
    }








    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public int compareTo(Rules otherRule){
        return Long.compare(this.id,otherRule.id);
    }
}
