package umbrella.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="Cart")
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="id")
    Long id;

    @Column(name="user_name")
    String userName;

    @OneToMany( cascade = CascadeType.ALL,orphanRemoval=true)
    @JoinColumn(name="cart_id")
    List<Item> itemList ;

    @Column(name="actual_value")
    Double actualValue;

    @Column(name="promoted_value")
    Double promotedValue;

    @Column(name="applied_promotion_name")
    String appliedPromotionName;


    public Cart() {

    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getAppliedPromotionName() {
        return appliedPromotionName;
    }

    public void setAppliedPromotionName(String appliedPromotionName) {
        this.appliedPromotionName = appliedPromotionName;
    }

    public Double getActualValue() {
        return actualValue;
    }

    public void setActualValue(Double actualValue) {
        this.actualValue = actualValue;
    }

    public Double getPromotedValue() {
        return promotedValue;
    }

    public void setPromotedValue(Double promotedValue) {
        this.promotedValue = promotedValue;
    }


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Item> getItemList() {
        return this.itemList;
    }

    public void setItemList(List<Item> itemList) {
        this.itemList = itemList;
    }




}
