package umbrella.dtos;

import java.util.List;
import java.util.Map;


public class CartDto {
    String userName;
    List<ItemDto> itemList;
    Double actualValue;
    Double promotedValue;
    String appliedPromotionName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Double getActualValue() {
        return actualValue;
    }

    public void setActualValue(Double actualValue) {
        this.actualValue = actualValue;
    }

    public Double getPromotedValue() {
        return promotedValue;
    }

    public void setPromotedValue(Double promotedValue) {
        this.promotedValue = promotedValue;
    }

    public String getAppliedPromotionName() {
        return appliedPromotionName;
    }

    public void setAppliedPromotionName(String appliedPromotionName) {
        this.appliedPromotionName = appliedPromotionName;
    }
    public List<ItemDto> getItemList() {
        return itemList;
    }

    public void setItemList(List<ItemDto> itemList) {
        this.itemList = itemList;
    }
}
