package umbrella.dtos;


public class ItemDto {
private String skuId ;
private Long count;
private double unitPrice;

    public ItemDto(String skuId, Double unitPrice) {
        this.skuId = skuId;
        this.unitPrice = unitPrice;
    }
    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public ItemDto() {

    }
    public String getSkuId() {
        return skuId;
    }


    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double price) {
        this.unitPrice = price;
    }

    public String toString(){ return this.skuId;}

}
