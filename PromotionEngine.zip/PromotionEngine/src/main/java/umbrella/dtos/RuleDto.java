package umbrella.dtos;

import umbrella.mapper.HashMapConverter;

import javax.persistence.Column;
import javax.persistence.Convert;
import java.util.HashMap;
import java.util.Map;

public class RuleDto {

    Long id;
    Double actualValue;
    Double promotionValue;
    Map<String, String> eligibilityCriteria = new HashMap<>();
    String promotionName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getActualValue() {
        return actualValue;
    }

    public void setActualValue(Double actualValue) {
        this.actualValue = actualValue;
    }

    public Double getPromotionValue() {
        return promotionValue;
    }

    public void setPromotionValue(Double promotionValue) {
        this.promotionValue = promotionValue;
    }

    public Map<String, String> getEligibilityCriteria() {
        return eligibilityCriteria;
    }

    public void setEligibilityCriteria(Map<String, String> eligibilityCriteria) {
        this.eligibilityCriteria = eligibilityCriteria;
    }

    public String getPromotionName() {
        return promotionName;
    }

    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }
}
