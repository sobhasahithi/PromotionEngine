package umbrella.mapper;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.io.IOException;
import java.util.HashMap;

@Converter
public class HashMapConverter implements AttributeConverter<HashMap<String, String>, String> {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(HashMap<String, String> attribute) {
        try {
            return objectMapper.writeValueAsString(attribute);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error converting JSON to HashMap", e);
        }
    }

    @Override
    public HashMap<String, String> convertToEntityAttribute(String dbData) {
        try {
             System.out.println(" *********************"+   dbData);
            HashMap<String, String> map = objectMapper.readValue( dbData, new TypeReference<HashMap<String,String>>(){});
        return map;
        } catch (IOException e) {
            throw new RuntimeException("Error converting HashMap to JSON", e);
        }
    }
}
