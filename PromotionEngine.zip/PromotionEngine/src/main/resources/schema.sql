drop table rules;
drop table item;
drop table cart;


/*Create table Cart ("id" number(20),"user_name" varchar2(200),
 "applied_promotion_name" varchar2(20), "actual_value" number(20) , "promoted_value" varchar2(50));

Create table Rules ("id" number(20), "type" varchar2(50), "quantity" number(2),
 "promotion_name" varchar2(200), "promotion_value"  number(20), "products_involved" varchar2(50));

Create table Item("id" number(20),"sku_id" varchar2(20), "unit_price" number(20));*/

/*insert into Rules(id , promotion_name ,promotion_value ,actual_value,eligibility_criteria)
values(1, '3A-Promotion' , 130 ,150,'{"A":"3"}');
insert into Rules(id ,  promotion_name ,promotion_value ,actual_value,eligibility_criteria)
values(2, '2B-Promotion' , 45 , 60,'{"B":"2"}');
insert into Rules(id , promotion_name ,promotion_value ,actual_value,eligibility_criteria)
values(3,'C+D-Promotion', 30 , 45, '{"C":"1","D":"1"}');*/


